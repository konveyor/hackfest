INSERT INTO products(id, name, description) VALUES (1, 'Grog', 'A secret mixture that contains one or more of the following: Kerosene, Propylene Glycol, Artificial Sweeteners, Sulfuric Acid, Rum, Acetone, Battery Acid, red dye#2, Scumm, Axle grease and/or pepperoni.');
INSERT INTO products(id, name, description) VALUES (2, 'Ship''s Horn', 'Made in Hong Kong');
INSERT INTO products(id, name, description) VALUES (3, 'Well-Polished Old Saw', 'Found at the bottom of the sea. Great condition.');
INSERT INTO products(id, name, description) VALUES (4, 'Rubber Chicken With A Pulley In The Middle', 'What possible use could this have?');
INSERT INTO products(id, name, description) VALUES (5, 'Idol of Many Hands', 'Also known as the Fabulous Idol');
INSERT INTO products(id, name, description) VALUES (6, 'How Much Wood? - Hardcover', 'From the Woodchuck Mystery series');